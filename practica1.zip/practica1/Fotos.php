<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<?php




?>
</head>

<body>
<table border="3" align="center">
<?php 
//este for nos pinta las filas
for($x=0;$x<2;$x++){
echo"<tr>";
echo"<td><img src='imagenes/pato1.jpg' width='150' height='150'></td>";
//echo"<td></td>";


// este for las columnas
for($i=0;$i<1;$i++){
echo"<td><img src='imagenes/pato4.jpg' width='150' height='150'</td>";



}
echo"</tr>";	
}


?>
</table>
</body>
</html>